var Worlist;
Wordlist = (function(_super) {
    __extends(Wordlist, _super);
    Wordlist.table_name = "wordlist";

    function Wordlist(){
        // call super
        Wordlist.__super__.constructor.apply(this, arguments);
    }

    Wordlist.prototype.class = Wordlist;
    return Wordlist;
})(AR);
