(function(context) {
    context.ENV = {
        WEB_DB_CONFIG: {
            database: 'mnmdict',
            table: 'mnmdict',
            size: 100*1024*1024,
            version: "1.0"
        } 
    }
})(window);
