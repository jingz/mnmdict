# A English <-> Thai Dictionary 
### [Chrome Extension](https://chrome.google.com/webstore/detail/minimal-en-th-en-dictiona/lcgmpehgdiaghhhhkaljhamggnbdgdig)
### [FireFox Add-On](https://addons.mozilla.org/en-US/firefox/addon/english-thai-dictionary/)
