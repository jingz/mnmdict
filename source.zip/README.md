A EN-TH Dictionary on Chrome Extension

https://chrome.google.com/webstore/detail/minimal-en-th-en-dictiona/lcgmpehgdiaghhhhkaljhamggnbdgdig
